export default {
    template: '<div>페이지 찾을 수 없다!!!</div>',
  };
  