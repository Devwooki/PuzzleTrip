export default {
  template: `<div>
    자유 게시판
    <router-view></router-view>
  </div>`,
};
