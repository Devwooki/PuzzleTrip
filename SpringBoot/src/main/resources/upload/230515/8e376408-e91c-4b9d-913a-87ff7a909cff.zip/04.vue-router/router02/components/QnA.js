export default {
  template: '<div>질문 게시판</div>',
};
