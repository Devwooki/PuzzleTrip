<template>
  <div class="regist">
    <h1>SSAFY 글 삭제</h1>
    <div>{{ message }} 를 삭제했습니다</div>
  </div>
</template>

<script>
export default {
  name: 'BoardDelete',
  data() {
    return {
      message: ' ',

    };
  },
  created() {
    // 비동기
    // TODO : 글번호에 해당하는 글을 삭제.
    this.articleNo = this.$route.params.articleNo;
    fetch('http://localhost:80/article/delete/' + this.articleNo)
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
        this.message = data;
        //this.$router.push("/board");
        this.$router.push({name : 'boardList'})
      });
  },
};
</script>

<style></style>
