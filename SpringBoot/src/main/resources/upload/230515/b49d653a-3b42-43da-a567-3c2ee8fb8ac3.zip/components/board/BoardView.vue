<template>
  <div class="regist">
    <h1 class="underline">SSAFY 글 상세보기</h1>
    <div class="regist_form">
      <label> 글번호</label>
      <div class="view">{{ list.articleNo }}</div>
      <label> 글제목</label>
      <div class="view">{{ list.subject }}</div>
      <label> 작성자</label>
      <div class="view">{{ list.userId }}</div>
      <label> 조회수</label>
      <div class="view">{{ list.hit }}</div>
      <label> 작성시간</label>
      <div class="view">{{ list.registTime }}</div>
      <label> 내용</label>
      <div class="view">{{ list.content }}</div>

      <div style="padding-top: 15px">
        <router-link :to="{name : 'boardModify', params :{ articleNo : list.articleNo }}">수정</router-link> |
        <router-link :to="{name : 'boardDelete', params: {articleNo : list.articleNo}}">삭제</router-link> |
        <router-link :to="{name : 'board'}">목록</router-link>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'BoardView',
  data() {
    return {
      list: [],
        articleNo: 0,
    };
  },
  created() {
      this.articleNo = this.$route.params.articleNo;
    fetch('http://localhost:80/article/view/' + this.articleNo)
      .then((response) => response.json())
      .then((data) => {
          console.log(data)
        this.list = data;
      });
  },
};
</script>

<style></style>

<script setup>
</script>