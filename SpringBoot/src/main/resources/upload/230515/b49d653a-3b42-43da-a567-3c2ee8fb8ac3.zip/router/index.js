import Vue from 'vue';
import VueRouter from 'vue-router';


import BoardList from "@/components/board/BoardList.vue";
import AppBoard from "@/views/AppBoard.vue";
import BoardModify from "@/components/board/BoardModify.vue";
import BoardWrite from "@/components/board/BoardWrite.vue";
import BoardView from "@/components/board/BoardView.vue";
import BoardDelete from "@/components/board/BoardDelete.vue";

Vue.use(VueRouter);

const routes = [
  {
    path: '/board',
    name: 'board',
    redirect : '/board/list',
    component : AppBoard,
    children : [
        {
          path : 'list',
          name : 'boardList',
          component : BoardList
        },
        {
          path : 'modify',
          name : 'boardModify',
          component: BoardModify
      },
       {
          path : 'write',
          name : 'boardWrite',
         component:  BoardWrite
       },
        {
            path : 'view',
            name : 'boardView',
            component: BoardView
        },
        {
            path :'delete',
            name : 'boardDelete',
            component: BoardDelete
        }
    ]
  },
];

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes,
});

export default router;
