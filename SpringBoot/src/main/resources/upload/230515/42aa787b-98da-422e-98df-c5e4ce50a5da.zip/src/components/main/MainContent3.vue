<template>
  <div>{{ planInfo }}</div>
</template>

<script>
export default {
  name: "MainContent3",
 
};
</script>

<style></style>
