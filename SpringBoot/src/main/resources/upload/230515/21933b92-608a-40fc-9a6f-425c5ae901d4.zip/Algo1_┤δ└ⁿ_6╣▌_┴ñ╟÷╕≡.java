import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class Algo1_대전_6반_정현모 {

	//토끼 로봇 - 앞바리보다 뒷다리가 튼
	//길이 : 뒷다리 > 앞다리 
	
	// 경주장 - 오르막길 / 내리막길 (지점마다 높이가 정해짐)
	// 각 높이 H ( 0 <= H <= 100 )
	// 경주장 길이 : 10 
	
	//자신의 한계치보다 높은 오르막 혹은 내리막은 이동 X
	
	public static void main(String[] args) throws NumberFormatException, IOException {
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		int T = Integer.parseInt(br.readLine());
		
		for(int t = 1; t <= T; t++) {
		
			int[] arr = Arrays.stream(br.readLine().split(" ")).mapToInt(Integer::parseInt).toArray();
			int up = 0;
			int down = 0;
			int tmp = 0;
			for(int i = 0; i < arr.length - 1; i++) {
				//현재 위치가 다음위치보다 크다 (그렇다면 내리막)
				if(arr[i] > arr[i+1]) {
					tmp = arr[i] - arr[i+1];
					down = Math.max(tmp, down);
				}
				//현재 위치가 다음위치보다 작다 (그렇다면 오르막)
				else if(arr[i] < arr[i+1]){
					tmp = arr[i+1] - arr[i];
					up = Math.max(tmp, up);
				}
				//같다면 따로 처리할필요 없다.
				else {
					continue;
				}
				
			}
			
			//5마리의 토끼 입력 받음
			int ans = 0;
			for(int r = 0; r < 5; r++) {
				
				StringTokenizer st = new StringTokenizer(br.readLine());
				int upH  = Integer.parseInt(st.nextToken());
				int downH = Integer.parseInt(st.nextToken());
				
				if(upH >= up && downH >= down)ans++;	
			} 
			
			System.out.println("#"+ t + " " + ans);	
		}	
	}
}
