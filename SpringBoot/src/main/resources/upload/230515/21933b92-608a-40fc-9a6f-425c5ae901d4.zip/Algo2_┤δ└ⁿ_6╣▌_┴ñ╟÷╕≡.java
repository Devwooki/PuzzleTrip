import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayDeque;
import java.util.Queue;
import java.util.StringTokenizer;

public class Algo2_대전_6반_정현모 {

	// 가로 세로 길이 같다
	// B 기둥을 E로 옮기려고 한다
	// 지형 0 - 아무것도 없음 / 1 - 벽 이라고 생각
	// B 와 E는 임의로 지정됨
	// 이동할 기둥의 길이는 항상 3
	// U(한칸위) D(한칸아래) L(한칸왼쪽) R(한칸오른쪽) T(90회전)
	// 턴을 가능하기 위해서는 3X3이 빈칸이여야 한다

	// bfs 레벨로 하면 가능할지도 ?

	static int[][] B, E, map;
	static int N;
	static Queue<Node> que;
	static boolean[][] visited;

	public static void main(String[] args) throws NumberFormatException, IOException {

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		N = Integer.parseInt(br.readLine());

		// 시작 위치
		B = new int[3][2];
		int bIdx = 0;
		// 도착 위치
		E = new int[3][2];
		int eIdx = 0;
		// 입력 받을 맵
		map = new int[N][N];

		// 값 입력 받기
		for (int i = 0; i < N; i++) {
			StringTokenizer st = new StringTokenizer(br.readLine(), "");
			for (int j = 0; j < N; j++) {
				String tmp = st.nextToken();
				if (tmp.equals("B")) {
					B[bIdx][0] = i;
					B[bIdx++][1] = j;
					map[i][j] = 0;
				} else if (tmp.equals("E")) {
					E[eIdx][0] = i;
					E[eIdx++][1] = j;
					map[i][j] = 0;

				} else
					map[i][j] = Integer.parseInt(tmp);
			}
		}

		// bfs (bfs로 하게 될경우)
		System.out.println(bfs());

	}

	public static class Node {
		int[] br, bc;

		public Node(int[] br, int[] bc) {
			this.br = br;
			this.bc = bc;
		}

	}

	private static int bfs() {
		// 초기값 세팅
		visited = new boolean[N][N];

		que = new ArrayDeque<>();

		int[] bR = new int[3];
		int[] bC = new int[3];

		for (int i = 0; i < 3; i++) {
			bR[i] = B[i][0];
			bC[i] = B[i][1];
		}
		Node tmpN = new Node(bR, bC);
		que.offer(tmpN);

		int level = 0;

		// 큐가 비어있지 않다면 반복해라
		whileEnd:
		while (!que.isEmpty()) {
			// 레벨 체크
			for (int i = 0; i < que.size(); i++) {

				Node qTmp = que.poll();

				// 현재 위치가 도착지점이라면
				// 도착 스택
				int cnt = 0;
				for(int j = 0; j < 3; i++) {
					if(qTmp.br[i] == E[j][0] && qTmp.br[i] == E[j][1])cnt++;
				}
				
				if(cnt == 3) break whileEnd;
				
				
				// 이동할수 있는 곳 상 / 하 / 좌 / 우 / 왼 90도 회전 체크
				moveCheck(qTmp);
			}
			// 레벨 증가
			level++;
		}

		return level;

	}

	// 좌 우 하 상
	static int[] dr = { 0, 0, -1, 1 };
	static int[] dc = { -1, 1, 0, 0 };

	private static void moveCheck(Node qTmp) {

		// 방문처리
		for (int i = 0; i < 3; i++) {
			visited[qTmp.br[i]][qTmp.bc[i]] = true;
		}

		for (int d = 0; d < 4; d++) {

			int[] nr = new int[3];
			int[] nc = new int[3];

			for (int b = 0; b < 3; b++) {
				nr[b] = qTmp.br[b] + dr[d];
				nc[b] = qTmp.bc[b] + dc[d];
			}
			// 방문체크 / 범위 체크 (성공시 - 현재 내가 갈수 있는 위치)
			if (mapCheck(nr, nc)) {
				// 큐에 넣어준다
				que.offer(new Node(nr, nc));
			}
		}

		// 90도 확인 (2가지 방법이 존재 ) --- |
		int Btype = -1;
		// | <- Btype = 0
		if (qTmp.br[0] + 1 == qTmp.br[1])
			Btype = 0;
		// --- <- Btype = 1
		else
			Btype = 1;

		int nr[] = new int[3];
		int nc[] = new int[3];
		int[] lotainR = new int[3];
		int[] lotainC = new int[3];
		int lotainIdx = 0;
		//양쪽 true 인지 확인!
		int twoCheck = 0;
		if (Btype == 0) {
			// 좌우 체크
			for (int d = 0; d < 2; d++) {
				for (int b = 0; b < 3; b++) {
					nr[b] = qTmp.br[b] + dr[d];
					nc[b] = qTmp.bc[b] + dc[d];
				}
				if(lotationCheck(nr,nc)) twoCheck++;
				lotainR[lotainIdx] = nr[2]; 
				lotainC[lotainIdx] = nc[2];
				lotainIdx += 2;
			}
			lotainR[1] = qTmp.br[1]; 
			lotainC[1] = qTmp.bc[1];

		} else {
			// 상하 체크
			for (int d = 2; d < 4; d++) {
				for (int b = 0; b < 3; b++) {
					nr[b] = qTmp.br[b] + dr[d];
					nc[b] = qTmp.bc[b] + dc[d];
				}
				if(lotationCheck(nr,nc)) twoCheck++;
				lotainR[lotainIdx] = nr[2]; 
				lotainC[lotainIdx] = nc[2];
				lotainIdx += 2;
			}
			lotainR[1] = qTmp.br[1]; 
			lotainC[1] = qTmp.bc[1];
		}
		
		//만약 양쪽다 갈수잇는곳이라면 90도 회전해
		if(twoCheck == 2) {
			que.offer(new Node(lotainR, lotainC));
		}
	}
	
	//회전 체크
	private static boolean lotationCheck(int[] nr, int[] nc) {
		
		int oneStack = 0;
		for (int i = 0; i < 3; i++) {
			// map 범위 밖이면 불가능!
			if (nr[i] < 0 || nr[i] >= N)
				return false;
			if (nc[i] < 0 || nc[i] >= N)
				return false;
			if(map[nr[i]][nc[i]] == 1)oneStack++;
		}
		//주면에  1이 있는가 없다면 가능 
		if(oneStack == 0) return true;
		//있다면 불가
		return false;
	}

	private static boolean mapCheck(int[] nr, int[] nc) {
		// 방문한 스택
		int visiStack = 0;
		for (int i = 0; i < 3; i++) {
			// map 범위 밖이면 불가능!
			if (nr[i] < 0 || nr[i] >= N)
				return false;
			if (nc[i] < 0 || nc[i] >= N)
				return false;
			// 방문 했었는지 확인 (방문했으면 방문스택 증가)
			if (visited[nr[i]][nc[i]])
				visiStack++;
		}
		// 방문 스택이 3 이상이면 (이미 왔던곳!)
		if (visiStack == 3)
			return false;
		// 모든 조건에 성립했으면 B가 이동할수 있는 위치
		return true;
	}

}
